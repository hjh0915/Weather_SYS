package com.work.Weather.deal;

import lombok.Data;

@Data
public class Index {
    public String title;
    public String level;
    public String desc;
}